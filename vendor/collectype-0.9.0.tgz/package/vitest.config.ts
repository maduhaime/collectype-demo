/// <reference types="vitest" />
import { fileURLToPath, URL } from 'url';
import { defineConfig } from 'vitest/config';

export default defineConfig({
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  test: {
    environment: 'node',
    coverage: {
      exclude: [
        '**/index.ts', // Index files
        '**/*.config.ts', // Configuration files
        '**/*.d.ts', // Type definitions
        'demo/**', // Demo files
        'dist/**', // Distribution files
        'src/enums/**', // Enumerations
        'src/interfaces/**', // Interfaces
        'src/types/**', // Types
      ],
    },
  },
});
